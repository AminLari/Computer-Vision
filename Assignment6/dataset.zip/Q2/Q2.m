%% Computer Vision Course - Assignment 06

%% Q2 - Mohammadamin Lari - Studemt# 66427311

%clc
clear all
close all

%N is the first N components in the descriptor
%version:
% 0 - orignial descriptor
% 1 - exclude DC component
% 2 - divide by first component (normalization)
% 3 - apply both 1 & 2

N = 4;        
version = 2;

trainImages = {};
trainImages{1} = imread('train\0_r.bmp');

trainDescriptors = {};
trainDescriptors{1} = FourierDescriptor(trainImages{1},N,version);
