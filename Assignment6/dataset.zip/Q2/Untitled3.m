I = imread('train\0_r.bmp');
I2 = circshift(I,10,2);
imwrite(I2, 'train\shifted.bmp');
