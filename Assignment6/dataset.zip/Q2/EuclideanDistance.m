function [distance] = EuclideanDistance(v1,v2)
%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes here
len =min(length(v1), length(v2));
distance = sqrt(sum((v1(1:len) - v2(1:len)).^2));
end

